package medicine;

public class Medicine {

}
